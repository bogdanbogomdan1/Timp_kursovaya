var searchData=
[
  ['galoiserror',['GaloisError',['../classGaloisError.html',1,'']]]
];
