var searchData=
[
  ['set_5fstart_5fbits',['set_start_bits',['../classLFSR__Galois.html#a19ed057987b9914475e367d1e583592d',1,'LFSR_Galois']]]
];
